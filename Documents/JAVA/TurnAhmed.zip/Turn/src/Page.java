
public class Page implements Turner{

	public String turn() {
		// Md Ahmed
		return "Going to the next page";
	}

}
