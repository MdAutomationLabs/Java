
public class Leaf implements Turner {

	public String turn() {
		// Md Ahmed
		return "Changing colors";
	}

}
