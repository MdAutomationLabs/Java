
public class Pancake implements Turner{

	public String turn () {
		// Md Ahmed
		return "Flipping!";
	}

}
