
public class TurnerTester {
	public static void main(String[] args) {

		Leaf oak = new Leaf();
		Page comic = new Page();
		Pancake jack = new Pancake();
		
		System.out.println(oak.turn());
		System.out.println(comic.turn());
		System.out.println(jack.turn());
	}
}
