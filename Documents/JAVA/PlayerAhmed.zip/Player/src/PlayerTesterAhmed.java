public class PlayerTesterAhmed {

	public static void main(String[] args) {
		// Md Ahmed
		BaseballPlayer bp1 = new BaseballPlayer(2143, "Mike", "front", 5);
		BaseballPlayer bp2 = new BaseballPlayer(143, "Shon", "front", 5.8);
		BasketballPlayer bp3 = new BasketballPlayer(143, "Anna", "front", 8);
		BasketballPlayer bp4 = new BasketballPlayer(143, "Daish", "front", 6);
		System.out.println(bp1.toString());
		System.out.println(bp2.toString());
		System.out.println(bp3.toString());
		System.out.println(bp4.toString());
	}

}
