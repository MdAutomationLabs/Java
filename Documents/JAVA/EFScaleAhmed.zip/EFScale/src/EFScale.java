
public class EFScale {
	private int windspeed;

	public EFScale(int windspeed) {
		this.setWindspeed(windspeed);
	}
	
	public int getWindspeed() {
		return windspeed;
	}

	public void setWindspeed(int windspeed) {
		this.windspeed = windspeed;
	}

	

	

	

}

