import javax.swing.JFrame;

public class EFScaleViewer {

	public static void main(String[] args) {
		// Md Ahmed
		
		//JComponent component = new EFScaleJComponent;
		 JFrame frame = new EFScaleFrame(null);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			frame.setVisible(true);
	}
	
	}

