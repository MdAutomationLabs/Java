
public class Button1ViewerTester {

	public static void main(String[] args) {
		Button1Viewer viewer = new Button1Viewer();
		viewer.setVisible(true);

	}

}
